export interface Registration {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  details: string;
  /** ISO 8601 timestamp of when the form was submitted. */
  submittedAt: string;
}

export const sampleRegistrations: Registration[] = [
  {
    id: "reg-7f3a91",
    name: "Nour El-Sayed",
    email: "nour.elsayed@contoso.com",
    phone: "+20 100 482 7163",
    company: "Contoso",
    details:
      "Attending with one colleague from our finance team. Vegetarian meal, please.",
    submittedAt: "2026-10-27T14:12:00+03:00",
  },
  {
    id: "reg-2c84d0",
    name: "Omar Farouk",
    email: "omar.farouk@fabrikam.com",
    phone: "+20 122 309 5518",
    company: "Fabrikam",
    details: "I will arrive around 10:30 because of an earlier client meeting.",
    submittedAt: "2026-10-27T09:47:00+03:00",
  },
  {
    id: "reg-b51e67",
    name: "Laila Hassan",
    email: "laila.hassan@northwindtraders.com",
    phone: "+20 111 764 2093",
    company: "Northwind Traders",
    details: "",
    submittedAt: "2026-10-26T18:05:00+03:00",
  },
  {
    id: "reg-09d4ac",
    name: "Karim Mansour",
    email: "k.mansour@woodgrovebank.com",
    phone: "+20 106 215 9847",
    company: "Woodgrove Bank",
    details:
      "Please send the invoice to our accounts payable team. Our purchase order number will follow by email once procurement approves it, which usually takes two to three working days.",
    submittedAt: "2026-10-26T11:31:00+03:00",
  },
  {
    id: "reg-e6f218",
    name: "Sara Abdelrahman",
    email: "sara.abdelrahman@lamnahealthcare.com",
    phone: "+20 127 548 3016",
    company: "Lamna Healthcare",
    details: "Wheelchair-accessible seating needed.",
    submittedAt: "2026-10-25T16:58:00+03:00",
  },
  {
    id: "reg-4a7c3b",
    name: "Youssef Adel",
    email: "youssef.adel@tailspintoys.com",
    phone: "+20 109 873 4462",
    company: "Tailspin Toys",
    details: "",
    submittedAt: "2026-10-24T13:20:00+03:00",
  },
  {
    id: "reg-d83b5e",
    name: "Mariam Khalil",
    email: "mariam.khalil@relecloud.com",
    phone: "+20 114 690 2275",
    company: "Relecloud",
    details:
      "Could you share the agenda ahead of time? Our team is still deciding who else should attend.",
    submittedAt: "2026-10-23T10:08:00+03:00",
  },
  {
    id: "reg-61c9f4",
    name: "Ahmed Fathy",
    email: "ahmed.fathy@fourthcoffee.com",
    phone: "+20 101 337 6928",
    company: "Fourth Coffee",
    details: "Gluten-free lunch option if available.",
    submittedAt: "2026-10-22T15:44:00+03:00",
  },
  {
    id: "reg-a25e80",
    name: "Hana Mostafa",
    email: "hana.mostafa@treyresearch.net",
    phone: "+20 128 451 0739",
    company: "Trey Research",
    details: "I may need to leave early, around 15:00.",
    submittedAt: "2026-10-21T12:36:00+03:00",
  },
  {
    id: "reg-3e0b72",
    name: "Tarek Saleh",
    email: "tarek.saleh@alpineskihouse.com",
    phone: "+20 155 206 8314",
    company: "Alpine Ski House",
    details: "",
    submittedAt: "2026-10-20T08:52:00+03:00",
  },
];
