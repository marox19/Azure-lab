import { Link, Outlet, useLocation, useSearchParams } from "react-router-dom";
import { motion } from "motion/react";
import { TicketCheck } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { cn } from "@/lib/utils";

// Two views share the home route so registrations submitted on the form are
// immediately visible in the admin view: "/" is the form, "/?view=admin" the
// admin list.
const NAV_ITEMS = [
  { key: "form", label: "Register", to: "/" },
  { key: "admin", label: "Admin", to: "/?view=admin" },
] as const;

export function AppShell() {
  const { pathname } = useLocation();
  const [searchParams] = useSearchParams();
  const currentView =
    pathname === "/"
      ? searchParams.get("view") === "admin"
        ? "admin"
        : "form"
      : null;

  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:bg-background focus:px-3 focus:py-2 focus:text-sm focus:font-medium focus:shadow-md focus:outline-2 focus:outline-ring"
      >
        Skip to content
      </a>
      <header className="sticky top-0 z-30 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/85">
        <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
          <Link
            to="/"
            className="flex min-w-0 items-center gap-2 rounded-md text-base font-semibold tracking-tight outline-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
          >
            <TicketCheck className="size-5 shrink-0" aria-hidden="true" />
            <span className="truncate">Event Registration</span>
          </Link>
          <nav aria-label="Main" className="h-full">
            <ul className="flex h-full items-stretch gap-1">
              {NAV_ITEMS.map((item) => {
                const active = currentView === item.key;
                return (
                  <li key={item.key} className="flex">
                    <Link
                      to={item.to}
                      aria-current={active ? "page" : undefined}
                      className={cn(
                        "-mb-px inline-flex items-center border-b-2 px-3 text-sm outline-none transition-colors focus-visible:outline-2 focus-visible:-outline-offset-4 focus-visible:outline-ring",
                        active
                          ? "border-primary font-semibold text-foreground"
                          : "border-transparent font-medium text-muted-foreground hover:text-foreground",
                      )}
                    >
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </div>
      </header>
      <main
        id="main-content"
        tabIndex={-1}
        className="flex flex-1 flex-col outline-none"
      >
        {/* key on pathname → each route re-mounts and replays the entrance.
            Entrance-only (no AnimatePresence/exit): an exit animation around
            <Outlet/> would animate the NEXT route's content, not the leaving one. */}
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.15, ease: "easeOut" }}
          className="flex-1"
        >
          <Outlet />
        </motion.div>
      </main>
      <Toaster />
    </div>
  );
}

export default AppShell;
