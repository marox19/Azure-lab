import {
  useId,
  useMemo,
  useRef,
  useState,
  type FormEvent,
  type ReactNode,
} from "react";
import { Link, useSearchParams } from "react-router-dom";
import { toast } from "sonner";
import {
  Building2,
  CircleCheckBig,
  Inbox,
  Mail,
  Phone,
  Trash2,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/states";
import { useConfirm } from "@/hooks/use-confirm";
import { cn } from "@/lib/utils";
import { sampleRegistrations, type Registration } from "@/data/registrations";

const DETAILS_MAX = 1000;
const DETAILS_PREVIEW_CHARS = 140;

type FieldName = "name" | "email" | "phone" | "company" | "details";
type FormValues = Record<FieldName, string>;
type FormErrors = Partial<Record<FieldName, string>>;

const FIELD_ORDER: FieldName[] = ["name", "email", "phone", "company", "details"];
const EMPTY_FORM: FormValues = {
  name: "",
  email: "",
  phone: "",
  company: "",
  details: "",
};

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_CHARACTERS = /^\+?[\d\s().-]+$/;

const submittedFormat = new Intl.DateTimeFormat(undefined, {
  dateStyle: "medium",
  timeStyle: "short",
});

function formatSubmitted(iso: string): string {
  return submittedFormat.format(new Date(iso));
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "";
  const first = parts[0].charAt(0);
  const last = parts.length > 1 ? parts[parts.length - 1].charAt(0) : "";
  return (first + last).toUpperCase();
}

function newRegistrationId(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `reg-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function validate(values: FormValues): FormErrors {
  const errors: FormErrors = {};
  const email = values.email.trim();
  const phone = values.phone.trim();

  if (!values.name.trim()) errors.name = "Enter your full name.";

  if (!email) errors.email = "Enter your email address.";
  else if (!EMAIL_PATTERN.test(email))
    errors.email = "Enter an email address like name@company.com.";

  if (!phone) {
    errors.phone = "Enter your phone number.";
  } else {
    const digits = phone.replace(/\D/g, "").length;
    if (!PHONE_CHARACTERS.test(phone) || digits < 7 || digits > 15)
      errors.phone = "Enter a phone number with 7 to 15 digits, like +20 100 123 4567.";
  }

  if (!values.company.trim()) errors.company = "Enter your company name.";

  if (values.details.length > DETAILS_MAX)
    errors.details = `Keep details to ${DETAILS_MAX.toLocaleString()} characters or fewer.`;

  return errors;
}

export function HomePage() {
  const [searchParams] = useSearchParams();
  const view = searchParams.get("view") === "admin" ? "admin" : "form";
  const [registrations, setRegistrations] =
    useState<Registration[]>(sampleRegistrations);

  const addRegistration = (registration: Registration) =>
    setRegistrations((current) => [registration, ...current]);
  const removeRegistration = (id: string) =>
    setRegistrations((current) => current.filter((r) => r.id !== id));

  return view === "admin" ? (
    <AdminView registrations={registrations} onDelete={removeRegistration} />
  ) : (
    <RegistrationView onSubmit={addRegistration} />
  );
}

/* ------------------------------------------------------------------ */
/* Registration form                                                   */
/* ------------------------------------------------------------------ */

function RegistrationView({
  onSubmit,
}: {
  onSubmit: (registration: Registration) => void;
}) {
  const [values, setValues] = useState<FormValues>(EMPTY_FORM);
  const [errors, setErrors] = useState<FormErrors>({});
  const [attempted, setAttempted] = useState(false);
  const [submitted, setSubmitted] = useState<Registration | null>(null);
  const fieldRefs = useRef<
    Partial<Record<FieldName, HTMLInputElement | HTMLTextAreaElement | null>>
  >({});
  const successHeadingRef = useRef<HTMLHeadingElement>(null);

  function update(field: FieldName, value: string) {
    const next = { ...values, [field]: value };
    setValues(next);
    if (attempted) setErrors(validate(next));
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const nextErrors = validate(values);
    setErrors(nextErrors);
    setAttempted(true);

    const firstInvalid = FIELD_ORDER.find((field) => nextErrors[field]);
    if (firstInvalid) {
      fieldRefs.current[firstInvalid]?.focus();
      return;
    }

    const registration: Registration = {
      id: newRegistrationId(),
      name: values.name.trim(),
      email: values.email.trim(),
      phone: values.phone.trim(),
      company: values.company.trim(),
      details: values.details.trim(),
      submittedAt: new Date().toISOString(),
    };
    onSubmit(registration);
    setSubmitted(registration);
    toast.success("Registration submitted");
    requestAnimationFrame(() => successHeadingRef.current?.focus());
  }

  function registerAnother() {
    setValues(EMPTY_FORM);
    setErrors({});
    setAttempted(false);
    setSubmitted(null);
    requestAnimationFrame(() => fieldRefs.current.name?.focus());
  }

  const pass = submitted ?? values;

  return (
    <div className="mx-auto grid w-full max-w-6xl gap-12 px-4 py-8 sm:px-6 lg:grid-cols-[minmax(0,1fr)_20rem] lg:gap-16 lg:py-12">
      <section aria-labelledby="register-heading" className="min-w-0">
        {submitted ? (
          <div className="max-w-xl">
            <CircleCheckBig
              className="size-10 text-green-700 dark:text-green-400"
              aria-hidden="true"
            />
            <h1
              id="register-heading"
              ref={successHeadingRef}
              tabIndex={-1}
              className="mt-4 text-3xl font-semibold tracking-tight outline-none"
            >
              You're registered
            </h1>
            <p className="mt-3 text-base text-muted-foreground">
              Thanks, {submitted.name.split(/\s+/)[0]}. Your registration was
              submitted on {formatSubmitted(submitted.submittedAt)}.
            </p>
            <Button size="lg" className="mt-8" onClick={registerAnother}>
              Register someone else
            </Button>
          </div>
        ) : (
          <>
            <h1
              id="register-heading"
              className="text-3xl font-semibold tracking-tight"
            >
              Register for the event
            </h1>
            <form
              noValidate
              onSubmit={handleSubmit}
              aria-labelledby="register-heading"
              className="mt-8 grid max-w-xl gap-6 sm:grid-cols-2"
            >
              <TextField
                field="name"
                label="Full name"
                autoComplete="name"
                className="sm:col-span-2"
                value={values.name}
                error={errors.name}
                onChange={(v) => update("name", v)}
                inputRef={(el) => {
                  fieldRefs.current.name = el;
                }}
              />
              <TextField
                field="email"
                label="Email"
                type="email"
                inputMode="email"
                autoComplete="email"
                value={values.email}
                error={errors.email}
                onChange={(v) => update("email", v)}
                inputRef={(el) => {
                  fieldRefs.current.email = el;
                }}
              />
              <TextField
                field="phone"
                label="Phone number"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                value={values.phone}
                error={errors.phone}
                onChange={(v) => update("phone", v)}
                inputRef={(el) => {
                  fieldRefs.current.phone = el;
                }}
              />
              <TextField
                field="company"
                label="Company name"
                autoComplete="organization"
                className="sm:col-span-2"
                value={values.company}
                error={errors.company}
                onChange={(v) => update("company", v)}
                inputRef={(el) => {
                  fieldRefs.current.company = el;
                }}
              />
              <DetailsField
                value={values.details}
                error={errors.details}
                onChange={(v) => update("details", v)}
                textareaRef={(el) => {
                  fieldRefs.current.details = el;
                }}
              />
              <div className="sm:col-span-2">
                <Button type="submit" size="lg" className="w-full sm:w-auto">
                  Submit registration
                </Button>
              </div>
            </form>
          </>
        )}
      </section>

      <AttendeePass
        name={pass.name}
        company={pass.company}
        email={pass.email}
        phone={pass.phone}
        submittedAt={submitted?.submittedAt ?? null}
      />
    </div>
  );
}

function TextField({
  field,
  label,
  type = "text",
  inputMode,
  autoComplete,
  className,
  value,
  error,
  onChange,
  inputRef,
}: {
  field: Exclude<FieldName, "details">;
  label: string;
  type?: "text" | "email" | "tel";
  inputMode?: "text" | "email" | "tel";
  autoComplete: string;
  className?: string;
  value: string;
  error?: string;
  onChange: (value: string) => void;
  inputRef: (el: HTMLInputElement | null) => void;
}) {
  const id = `registration-${field}`;
  const errorId = `${id}-error`;
  return (
    <div className={cn("grid content-start gap-2", className)}>
      <Label htmlFor={id}>{label}</Label>
      <Input
        ref={inputRef}
        id={id}
        name={field}
        type={type}
        inputMode={inputMode}
        autoComplete={autoComplete}
        required
        value={value}
        onChange={(event) => onChange(event.target.value)}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? errorId : undefined}
        className="h-11 text-base md:text-base"
      />
      {error && (
        <p id={errorId} className="text-sm text-destructive">
          {error}
        </p>
      )}
    </div>
  );
}

function DetailsField({
  value,
  error,
  onChange,
  textareaRef,
}: {
  value: string;
  error?: string;
  onChange: (value: string) => void;
  textareaRef: (el: HTMLTextAreaElement | null) => void;
}) {
  const id = "registration-details";
  const limitId = `${id}-limit`;
  const errorId = `${id}-error`;
  return (
    <div className="grid gap-2 sm:col-span-2">
      <div className="flex items-baseline justify-between gap-3">
        <Label htmlFor={id}>
          Details{" "}
          <span className="font-normal text-muted-foreground">(optional)</span>
        </Label>
        <span
          aria-hidden="true"
          className="text-xs tabular-nums text-muted-foreground"
        >
          {value.length.toLocaleString()} / {DETAILS_MAX.toLocaleString()}
        </span>
      </div>
      <Textarea
        ref={textareaRef}
        id={id}
        name="details"
        rows={5}
        maxLength={DETAILS_MAX}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${limitId} ${errorId}` : limitId}
        className="min-h-32 text-base md:text-base"
      />
      <span id={limitId} className="sr-only">
        Up to {DETAILS_MAX.toLocaleString()} characters.
      </span>
      {error && (
        <p id={errorId} className="text-sm text-destructive">
          {error}
        </p>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Attendee pass — the registration being created, as an object        */
/* ------------------------------------------------------------------ */

function AttendeePass({
  name,
  company,
  email,
  phone,
  submittedAt,
}: {
  name: string;
  company: string;
  email: string;
  phone: string;
  submittedAt: string | null;
}) {
  const displayName = name.trim();
  const displayCompany = company.trim();
  const mark = initials(displayName);

  return (
    <figure
      aria-labelledby="attendee-pass-caption"
      className="mx-auto w-full max-w-80 lg:sticky lg:top-24 lg:self-start"
    >
      <LanyardStrap />
      <div className="-mt-2 overflow-hidden rounded-2xl border bg-card text-card-foreground shadow-lg shadow-black/5">
        <div className="flex flex-col items-center bg-foreground px-6 pt-3 pb-4 text-background">
          <span
            aria-hidden="true"
            className="h-2 w-14 rounded-full bg-background/35"
          />
          <p className="mt-3 text-xs font-semibold tracking-[0.3em] uppercase">
            Attendee
          </p>
        </div>

        <div className="flex flex-col items-center px-6 pt-7 pb-6 text-center">
          <div
            aria-hidden="true"
            className={cn(
              "grid size-20 place-items-center rounded-full text-2xl font-semibold",
              mark
                ? "bg-muted text-foreground"
                : "border-2 border-dashed border-border",
            )}
          >
            {mark}
          </div>
          <p className="mt-5 w-full text-2xl leading-tight font-semibold break-words">
            {displayName || (
              <Placeholder className="mx-auto h-6 w-44" label="Name not entered yet" />
            )}
          </p>
          <p className="mt-2 w-full text-base break-words text-muted-foreground">
            {displayCompany || (
              <Placeholder
                className="mx-auto h-4 w-32"
                label="Company not entered yet"
              />
            )}
          </p>
        </div>

        <dl className="grid gap-2.5 border-t border-dashed px-6 py-4 text-sm">
          <PassLine icon={Mail} label="Email" value={email.trim()} />
          <PassLine icon={Phone} label="Phone" value={phone.trim()} />
        </dl>

        {submittedAt && (
          <p className="flex items-center justify-center gap-2 border-t bg-muted px-6 py-3 text-sm font-medium">
            <CircleCheckBig
              className="size-4 text-green-700 dark:text-green-400"
              aria-hidden="true"
            />
            Registered {formatSubmitted(submittedAt)}
          </p>
        )}
      </div>
      <figcaption
        id="attendee-pass-caption"
        className="mt-3 text-center text-sm text-muted-foreground"
      >
        Attendee pass
      </figcaption>
    </figure>
  );
}

function LanyardStrap() {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 160 64"
      fill="none"
      className="mx-auto block h-16 w-40 text-muted-foreground"
    >
      <path d="M30 0 L70 50" stroke="currentColor" strokeOpacity="0.35" strokeWidth="12" />
      <path d="M130 0 L90 50" stroke="currentColor" strokeOpacity="0.35" strokeWidth="12" />
      <rect x="64" y="44" width="32" height="20" rx="5" fill="currentColor" fillOpacity="0.7" />
      <rect x="72" y="50" width="16" height="6" rx="3" className="fill-background" />
    </svg>
  );
}

function PassLine({
  icon: Icon,
  label,
  value,
}: {
  icon: LucideIcon;
  label: string;
  value: string;
}) {
  return (
    <div className="flex min-w-0 items-center gap-3">
      <dt className="shrink-0">
        <Icon className="size-4 text-muted-foreground" aria-hidden="true" />
        <span className="sr-only">{label}</span>
      </dt>
      <dd className="min-w-0 break-all">
        {value || <Placeholder className="h-3.5 w-40" label="Not entered yet" />}
      </dd>
    </div>
  );
}

function Placeholder({ className, label }: { className?: string; label: string }) {
  return (
    <>
      <span aria-hidden="true" className={cn("block rounded-md bg-muted", className)} />
      <span className="sr-only">{label}</span>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Admin view — every submitted form as its own entry                  */
/* ------------------------------------------------------------------ */

function AdminView({
  registrations,
  onDelete,
}: {
  registrations: Registration[];
  onDelete: (id: string) => void;
}) {
  const confirm = useConfirm();
  const sorted = useMemo(
    () =>
      [...registrations].sort(
        (a, b) => Date.parse(b.submittedAt) - Date.parse(a.submittedAt),
      ),
    [registrations],
  );

  async function handleDelete(registration: Registration) {
    const ok = await confirm({
      title: "Delete this registration?",
      description: `${registration.name} from ${registration.company} will be removed from the list.`,
      confirmLabel: "Delete",
      destructive: true,
    });
    if (!ok) return;
    onDelete(registration.id);
    toast.success(`Deleted ${registration.name}'s registration`);
  }

  const count = sorted.length;

  return (
    <section
      aria-labelledby="admin-heading"
      className="mx-auto w-full max-w-6xl px-4 py-8 sm:px-6 lg:py-12"
    >
      <div className="flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1">
        <h1 id="admin-heading" className="text-3xl font-semibold tracking-tight">
          Registrations
        </h1>
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {count} {count === 1 ? "registration" : "registrations"}
        </p>
      </div>

      {count === 0 ? (
        <EmptyState
          icon={Inbox}
          title="No registrations yet"
          className="mt-8 rounded-xl border border-dashed"
          action={
            <Button asChild variant="outline">
              <Link to="/">Open the registration form</Link>
            </Button>
          }
        />
      ) : (
        <ul role="list" className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {sorted.map((registration) => (
            <li key={registration.id} className="flex">
              <RegistrationCard
                registration={registration}
                onDelete={() => handleDelete(registration)}
              />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function RegistrationCard({
  registration,
  onDelete,
}: {
  registration: Registration;
  onDelete: () => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const headingId = useId();
  const detailsId = useId();
  const { name, company, email, phone, details, submittedAt } = registration;
  const isLong = details.length > DETAILS_PREVIEW_CHARS;

  return (
    <article
      aria-labelledby={headingId}
      className="flex w-full flex-col rounded-xl border bg-card text-card-foreground shadow-xs"
    >
      <div className="flex items-start gap-3 p-5 pb-4">
        <div
          aria-hidden="true"
          className="grid size-11 shrink-0 place-items-center rounded-full bg-muted text-sm font-semibold"
        >
          {initials(name)}
        </div>
        <div className="min-w-0 flex-1">
          <h2
            id={headingId}
            className="truncate text-base leading-snug font-semibold"
          >
            {name}
          </h2>
          <p className="mt-0.5 flex min-w-0 items-center gap-1.5 text-sm text-muted-foreground">
            <Building2 className="size-3.5 shrink-0" aria-hidden="true" />
            <span className="sr-only">Company:</span>
            <span className="truncate">{company}</span>
          </p>
        </div>
        <Button
          variant="ghost"
          size="icon-sm"
          onClick={onDelete}
          aria-label={`Delete registration from ${name}`}
          className="-mt-1 -mr-2 text-muted-foreground hover:text-destructive"
        >
          <Trash2 aria-hidden="true" />
        </Button>
      </div>

      <dl className="grid gap-3 border-t px-5 py-4 text-sm">
        <CardField label="Email">
          <span className="break-all select-all">{email}</span>
        </CardField>
        <CardField label="Phone">
          <span className="tabular-nums select-all">{phone}</span>
        </CardField>
        <CardField label="Details">
          {details ? (
            <>
              <p
                id={detailsId}
                className={cn(
                  "break-words whitespace-pre-wrap",
                  isLong && !expanded && "line-clamp-3",
                )}
              >
                {details}
              </p>
              {isLong && (
                <button
                  type="button"
                  aria-expanded={expanded}
                  aria-controls={detailsId}
                  onClick={() => setExpanded((open) => !open)}
                  className="mt-1 rounded-sm text-sm font-medium text-primary underline-offset-4 outline-none hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring"
                >
                  {expanded ? "Show less" : "Show more"}
                </button>
              )}
            </>
          ) : (
            <span className="text-muted-foreground">None</span>
          )}
        </CardField>
      </dl>

      <p className="mt-auto border-t px-5 py-3 text-xs text-muted-foreground">
        Submitted <time dateTime={submittedAt}>{formatSubmitted(submittedAt)}</time>
      </p>
    </article>
  );
}

function CardField({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <div className="grid grid-cols-[4rem_minmax(0,1fr)] gap-3">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="min-w-0">{children}</dd>
    </div>
  );
}
